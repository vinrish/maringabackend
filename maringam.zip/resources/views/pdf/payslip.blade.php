<!DOCTYPE html>
<html>
<head>
    <title>Payslip for {{ \Carbon\Carbon::createFromDate($payroll->year, $payroll->month, 1)->format('F Y') }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 8px; /* Reduced font size for thermal printer */
        }

        .content {
            width: 70mm; /* Set content width to 70mm for thermal printer */
            margin: 0 auto; /* Center align the content horizontally */
            padding: 0;
        }

        .text-center {
            text-align: center;
        }

        .detail-item {
            display: flex;
            line-height: 1.2em; /* Compact line spacing */
        }

        .label {
            text-align: left;
            width: 50%;
            white-space: nowrap; /* Prevent labels from wrapping */
        }

        .value {
            text-align: right;
            width: 50%;
            white-space: nowrap; /* Prevent values from wrapping */
        }

        .section-title {
            font-weight: bold;
        }

        hr {
            border: none;
            border-top: 0.5px solid black;
            margin: 0;
        }

        .net-pay-section {
            font-weight: bold;
            font-size: 10px; /* Slightly larger font for NET PAY */
        }
    </style>
</head>
<body>
<div class="content">
    <!-- Company Info -->
    <div class="text-center">
        <div>{{ $payroll->employee->company->name }}</div>
        <div>{{ $payroll->employee->company->kra_pin }}</div>
    </div>

    <hr />

    <!-- Payslip Title -->
    <div class="text-center">
        <div>
            <h3>
                Payslip for {{ \Carbon\Carbon::createFromDate($payroll->year, $payroll->month, 1)->format('F Y') }}
            </h3>
        </div>
    </div>

    <hr />

    <!-- Employee Details -->
    <div>
        <div class="detail-item">
            <span class="label">Name:</span>
            <span class="value">{{ $payroll->employee->user->first_name }} {{ $payroll->employee->user->last_name }}</span>
        </div>
        <div class="detail-item">
            <span class="label">ID:</span>
            <span class="value">{{ $payroll->employee->id_no }}</span>
        </div>
        <div class="detail-item">
            <span class="label">KRA PIN:</span>
            <span class="value">{{ $payroll->employee->kra_pin }}</span>
        </div>
    </div>

    <hr />

    <!-- Payments Section -->
    <div>
        <div class="section-title">PAYMENTS</div>
        <div class="detail-item">
            <span class="label">Gross Salary:</span>
            <span class="value">{{ number_format($payroll->employee->salary, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Other Pay:</span>
            <span class="value">{{ number_format($payroll->other_pay, 2) }}</span>
        </div>
    </div>

    <hr />

    <!-- Deductions Section -->
    <div>
        <div class="section-title">DEDUCTIONS</div>
        <div class="detail-item">
            <span class="label">NSSF:</span>
            <span class="value">{{ number_format($payroll->nssf_employee_contribution, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Taxable Income:</span>
            <span class="value">{{ number_format($payroll->taxable_income, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Income Tax:</span>
            <span class="value">{{ number_format($payroll->paye, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Personal Relief:</span>
            <span class="value">-{{ number_format($payroll->paye_relief, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Insurance Relief:</span>
            <span class="value">-{{ number_format($payroll->nhif_employee_contribution, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">AHL Relief:</span>
            <span class="value">-{{ number_format($payroll->housing_levy_relief, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">P.A.Y.E:</span>
            <span class="value">{{ number_format($payroll->paye_net, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">SHIF:</span>
            <span class="value">{{ number_format($payroll->nhif_employee_contribution, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Housing Levy:</span>
            <span class="value">{{ number_format($payroll->housing_levy, 2) }}</span>
        </div>
        <div class="detail-item">
            <span class="label">Total Deductions:</span>
            <span class="value">{{ number_format($payroll->total_deductions, 2) }}</span>
        </div>
    </div>

    <hr />

    <!-- Net Pay Section -->
    <div class="net-pay-section">
        <div class="detail-item">
            <span class="label">NET PAY:</span>
            <span class="value">{{ number_format($payroll->net_salary, 2) }}</span>
        </div>
    </div>
</div>
</body>
</html>
