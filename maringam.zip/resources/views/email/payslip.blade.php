<!DOCTYPE html>
<html>
<head>
    <title>Payslip for {{ \Carbon\Carbon::createFromDate($payroll->year, $payroll->month, 1)->format('F Y') }}</title>
</head>
<body>
<h1>Payslip for {{ \Carbon\Carbon::createFromDate($payroll->year, $payroll->month, 1)->format('F Y') }}</h1>
<p>Dear {{ $payroll->employee->user->first_name }} {{ $payroll->employee->user->last_name }},</p>
<p>Find the attached payslip for your payslip details.</p>
<p>Thank you for your hard work!</p>
</body>
</html>
