<?php

namespace App\Mail;

use App\Models\Payroll;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use PDF;
use Mpdf\Mpdf;

class PayslipMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public $payroll;

    /**
     * Create a new message instance.
     */
    public function __construct(Payroll $payroll)
    {
        $this->payroll = $payroll;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
//        return new Envelope(
//            'Your Payslip for ' . $this->payroll->month . ' ' . $this->payroll->year,
//        );
        return new Envelope(
            subject: 'Your Payslip for ' . $this->payroll->month . ' ' . $this->payroll->year
        );
    }


    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'email.payslip', // Ensure this matches the path of your view file
            with: [
                'payroll' => $this->payroll,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        // Create an instance of mPDF
        $mpdf = new Mpdf([
            'mode' => 'utf-8',
            'format' => [70, 100], // Width 80mm, Height 297mm (A4 thermal paper)
            'orientation' => 'P', // Portrait
            'default_font_size' => 8, // Small font for compact printing
            'default_font' => 'Arial',
            'margin_left' => 0,
            'margin_right' => 0,
            'margin_top' => 0,
            'margin_bottom' => 0,
        ]);

        $html = view('pdf.payslip', ['payroll' => $this->payroll])->render();
        $mpdf->WriteHTML($html);
        $mpdf->SetProtection(['copy','print'], $this->payroll->employee->id_no);

        $pdfOutput = $mpdf->Output('', 'S');

        return [
            \Illuminate\Mail\Mailables\Attachment::fromData(
                fn () => $pdfOutput,
                'payslip_' . $this->payroll->month . '_' . $this->payroll->year . '.pdf'
            )->withMime('application/pdf'),
        ];
    }
}
