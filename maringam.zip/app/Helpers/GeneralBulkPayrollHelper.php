<?php

namespace App\Helpers;

class GeneralBulkPayrollHelper
{}
