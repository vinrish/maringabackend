{{--<!DOCTYPE html>--}}
{{--<html>--}}
{{--<head>--}}
{{--    <title>Payslip</title>--}}
{{--    <style>--}}
{{--        /* Add your CSS styles here */--}}
{{--        body {--}}
{{--            font-family: Arial, sans-serif;--}}
{{--            margin: 0;--}}
{{--            padding: 20px;--}}
{{--        }--}}
{{--        .header {--}}
{{--            text-align: center;--}}
{{--            margin-bottom: 20px;--}}
{{--        }--}}
{{--        .content {--}}
{{--            width: 100%;--}}
{{--            border-collapse: collapse;--}}
{{--        }--}}
{{--        .content, .content th, .content td {--}}
{{--            border: 1px solid #000;--}}
{{--        }--}}
{{--        .content th, .content td {--}}
{{--            padding: 10px;--}}
{{--            text-align: left;--}}
{{--        }--}}
{{--    </style>--}}
{{--</head>--}}
{{--<body>--}}
{{--<div class="header">--}}
{{--    <h1>Payslip</h1>--}}
{{--    @if($company)--}}
{{--        <p>{{ $company->name }}</p>--}}
{{--        <p>{{ $company->address }}</p>--}}
{{--        <p>{{ $company->phone }}</p>--}}
{{--    @else--}}
{{--        <p>Company information not available.</p>--}}
{{--    @endif--}}
{{--</div>--}}
{{--<table class="content">--}}
{{--    <tr>--}}
{{--        <th>Employee Name</th>--}}
{{--        <td>@if($employee) {{ $employee->first_name }} {{ $employee->last_name }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>ID</th>--}}
{{--        <td>@if($employee) {{ $employee->id_no }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>KRA PIN</th>--}}
{{--        <td>@if($employee) {{ $employee->kra_pin }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Department</th>--}}
{{--        <td>@if($employee) {{ $employee->department }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Position</th>--}}
{{--        <td>@if($employee) {{ $employee->position }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Gross Salary</th>--}}
{{--        <td>@if($payroll) {{ $payroll->gross_salary }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <tr>--}}
{{--        <th>Net Salary</th>--}}
{{--        <td>@if($payroll) {{ $payroll->net_salary }} @else N/A @endif</td>--}}
{{--    </tr>--}}
{{--    <!-- Add more fields as needed -->--}}
{{--</table>--}}
{{--</body>--}}
{{--</html>--}}
